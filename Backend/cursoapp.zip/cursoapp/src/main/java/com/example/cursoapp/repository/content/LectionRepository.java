package com.example.cursoapp.repository.content;

import com.example.cursoapp.domain.entity.content.Lection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LectionRepository extends JpaRepository<Lection, Long> {
    List<Lection> findByModuleId(Long moduleId);
}